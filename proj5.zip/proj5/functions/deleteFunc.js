checkboxes = document.getElementsByName("yeah");
function printre()
{
    document.getElementById("yeah1").innerHTML = checkboxes[3].value ;
}
