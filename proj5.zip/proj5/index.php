<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
    <link href="css/mainpage.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Bowlby+One+SC&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Bowlby+One+SC|Lato&display=swap" rel="stylesheet">
</head>
<body>
    <div class="fp">
        <div class="title">
            <h1 class="logo">To</h1>
        </div>
        <div class="desc">
            <p class="toprow">ToWho is a website that keeps tracks on everything on your to do list
            You can add tasks, delete tasks, edit tasks etc.
                <p>This is your one stop shop to keep all of your tasks in one place all for the price of Free.99.</P>
             <p>To get started you can sign up or if you already have an account, sign in.</p>
        </div>
        <div class="rheading">
            <h1 class="rheading2"> WHO</h1>
        </div>
        
        <div class="btn1">
            <form action="SignIn/login.php">
                <input class="btn1" type="submit" value="Sign In!">
            </form>
        </div>
        <div class="btn2">
            <form action="SignUp/signup.php">
                <input class="btn2" type="submit" value="Create an Account!">
            </form>
        </div>
            </div>

</body>
</html>
