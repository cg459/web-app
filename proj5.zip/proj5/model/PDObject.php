<?php
    $servername =  "sql1.njit.edu";
    $username = "clc48";
    $password = "HG3DV8vpW";
    $database = "clc48";
    try{
        $db = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    }catch (PDOException $e)
    {
        $error_message = $e->getMessage();
        echo "seems like their was an error";
    }
?>
