<?php
    print_r($_POST['check_list']);

?>
